<!-- component -->

<template>
  <table id = "tabl">
    <tr>
      <td> 제목 </td>
      <td> 게시일 </td>
      <td> 작성자 </td>
    </tr>
    <tr>
    </tr>
    <tr>
    </tr>
    <tr>
    </tr>
    <tr>
    </tr>
    <tr>
    </tr>
    <tr>
    </tr>
    <tr>
    </tr>
    <tr>
    </tr>
    <tr>
    </tr>
    <tr>
    </tr>
  </table>
</template>

<script>
export default {
  name: 'oldman',
  data () {
    return {
      
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
